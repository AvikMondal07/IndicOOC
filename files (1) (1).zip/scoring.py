"""
IndicOOC scoring module.

Baselines behind one interface:
  O2-i   zero-shot      — SigLIP sigmoid score thresholded (no training)
  O2-ii  trained probe  — logistic regression on frozen SigLIP embeddings
  O2-iii encoder sweep  — the same pair scored by English-only vs multilingual
                          encoders, to test the Section 5.2 transfer assumption

app.py and the notebooks both import from here.
"""

from io import BytesIO
from pathlib import Path
from typing import Optional, Tuple

import numpy as np
import requests
import torch
from PIL import Image
from transformers import AutoModel, AutoProcessor

ENCODERS = {
    "siglip_en": "google/siglip-base-patch16-224",
    "siglip_multi": "google/siglip-base-patch16-256-multilingual",
    "siglip2": "google/siglip2-base-patch16-224",
}

ENCODER_LABELS = {
    "siglip_en": "SigLIP (English-trained)",
    "siglip_multi": "SigLIP (multilingual)",
    "siglip2": "SigLIP 2",
}

DEFAULT_ENCODER = "siglip_en"
MODEL_NAME = ENCODERS[DEFAULT_ENCODER]
DEFAULT_THRESHOLD = 0.5
PROBE_PATH = Path(__file__).parent.parent / "models" / "probe.joblib"

_loaded = {}
_device = None
_probe = None


def get_device() -> str:
    return "cuda" if torch.cuda.is_available() else "cpu"


def load_encoder(encoder: str = DEFAULT_ENCODER):
    global _device
    if encoder not in ENCODERS:
        raise ValueError(f"unknown encoder {encoder!r}; choose from {list(ENCODERS)}")
    if _device is None:
        _device = get_device()
    if encoder not in _loaded:
        name = ENCODERS[encoder]
        processor = AutoProcessor.from_pretrained(name)
        model = AutoModel.from_pretrained(name).to(_device)
        model.eval()
        _loaded[encoder] = (model, processor)
    model, processor = _loaded[encoder]
    return model, processor, _device


def load_model():
    return load_encoder(DEFAULT_ENCODER)


def load_image_from_url(url: str, timeout: int = 15) -> Optional[Image.Image]:
    try:
        resp = requests.get(url, timeout=timeout, headers={"User-Agent": "Mozilla/5.0"})
        resp.raise_for_status()
        return Image.open(BytesIO(resp.content)).convert("RGB")
    except Exception:
        return None


def _encode(image: Image.Image, claim_text: str, encoder: str = DEFAULT_ENCODER):
    model, processor, device = load_encoder(encoder)
    inputs = processor(
        text=[claim_text],
        images=image,
        padding="max_length",
        truncation=True,
        return_tensors="pt",
    ).to(device)
    with torch.no_grad():
        outputs = model(**inputs)
        img_emb = outputs.image_embeds[0]
        txt_emb = outputs.text_embeds[0]
        raw_score = torch.sigmoid(outputs.logits_per_image)[0][0].item()
    img_emb = img_emb / img_emb.norm()
    txt_emb = txt_emb / txt_emb.norm()
    return img_emb.cpu().numpy(), txt_emb.cpu().numpy(), raw_score


def build_features(img_emb: np.ndarray, txt_emb: np.ndarray) -> np.ndarray:
    cosine = float(np.dot(img_emb, txt_emb))
    return np.concatenate([img_emb * txt_emb, [cosine]])


def score_pair(image: Image.Image, claim_text: str, encoder: str = DEFAULT_ENCODER) -> float:
    _, _, raw_score = _encode(image, claim_text, encoder)
    return raw_score


def classify(score: float, threshold: float = DEFAULT_THRESHOLD) -> str:
    """Threshold a match score into two of IndicOOC's three classes.

    Deliberately does NOT implement 'insufficient_evidence' — a bare
    similarity score cannot express "not enough information".
    """
    return "supported" if score > threshold else "out_of_context"


def score_and_classify(
    image: Image.Image,
    claim_text: str,
    threshold: float = DEFAULT_THRESHOLD,
    encoder: str = DEFAULT_ENCODER,
) -> Tuple[str, float]:
    score = score_pair(image, claim_text, encoder)
    return classify(score, threshold), score


def compare_encoders(
    image: Image.Image,
    claim_text: str,
    threshold: float = DEFAULT_THRESHOLD,
    encoders=None,
) -> dict:
    """Score one pair with every encoder. Missing checkpoints are reported,
    not raised, so a download failure cannot take down the demo."""
    out = {}
    for enc in encoders or list(ENCODERS):
        try:
            score = score_pair(image, claim_text, enc)
            out[enc] = {
                "label": classify(score, threshold),
                "score": score,
                "error": None,
            }
        except Exception as e:
            out[enc] = {"label": None, "score": None, "error": str(e)}
    return out


def load_probe():
    global _probe
    if _probe is None:
        import joblib

        if not PROBE_PATH.exists():
            return None
        _probe = joblib.load(PROBE_PATH)
    return _probe


def probe_classify(image: Image.Image, claim_text: str) -> Optional[Tuple[str, float]]:
    probe = load_probe()
    if probe is None:
        return None
    img_emb, txt_emb, _ = _encode(image, claim_text)
    feats = build_features(img_emb, txt_emb).reshape(1, -1)
    proba = probe.predict_proba(feats)[0]
    idx = int(np.argmax(proba))
    return list(probe.classes_)[idx], float(proba[idx])


def compare_both(
    image: Image.Image, claim_text: str, threshold: float = DEFAULT_THRESHOLD
) -> dict:
    img_emb, txt_emb, raw_score = _encode(image, claim_text)
    out = {
        "zeroshot_label": classify(raw_score, threshold),
        "zeroshot_score": raw_score,
        "probe_label": None,
        "probe_confidence": None,
    }
    probe = load_probe()
    if probe is not None:
        feats = build_features(img_emb, txt_emb).reshape(1, -1)
        proba = probe.predict_proba(feats)[0]
        idx = int(np.argmax(proba))
        out["probe_label"] = list(probe.classes_)[idx]
        out["probe_confidence"] = float(proba[idx])
    return out
