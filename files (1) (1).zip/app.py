"""
IndicOOC — Streamlit MVP 2.0

Baselines shown side by side on the same (image, claim) pair:
  O2-i   zero-shot SigLIP threshold  (no training)
  O2-ii  logistic probe on frozen SigLIP embeddings (trained on train.csv)
  O2-iii encoder transfer sweep — English-only vs multilingual encoders

Run:
    streamlit run app/app.py
"""

from pathlib import Path

import pandas as pd
import streamlit as st
from PIL import Image

from scoring import (
    DEFAULT_THRESHOLD,
    ENCODER_LABELS,
    ENCODERS,
    compare_both,
    compare_encoders,
    load_image_from_url,
    load_model,
    load_probe,
)

DATA_DIR = Path(__file__).parent.parent / "data" / "annotations"
PILOT_CSV = DATA_DIR / "pilot_v0.csv"
TEST_CSV = DATA_DIR / "splits" / "test.csv"
OUT_DIR = Path(__file__).parent.parent / "outputs"
METRICS_CSV = OUT_DIR / "baseline_comparison.csv"
ENCODER_CSV = OUT_DIR / "encoder_comparison.csv"

st.set_page_config(page_title="IndicOOC", page_icon="🔎", layout="centered")


@st.cache_resource(show_spinner="Loading SigLIP (first run only)…")
def get_model():
    return load_model()


@st.cache_data
def read_csv(path):
    return pd.read_csv(path) if Path(path).exists() else None


def render_comparison(result, threshold, ground_truth=None):
    col1, col2 = st.columns(2)

    with col1:
        st.markdown("**O2-i — Zero-shot**")
        label = result["zeroshot_label"]
        color = "green" if label == "supported" else "red"
        st.markdown(f":{color}[{label.upper()}]")
        st.progress(
            min(max(result["zeroshot_score"], 0.0), 1.0),
            text=f"score {result['zeroshot_score']:.3f} (thr {threshold:.2f})",
        )
        st.caption("No training — pretrained SigLIP similarity only.")

    with col2:
        st.markdown("**O2-ii — Trained probe**")
        if result["probe_label"] is None:
            st.info("No probe fitted yet — run notebook 04.")
        else:
            label = result["probe_label"]
            color = "green" if label == "supported" else "red"
            st.markdown(f":{color}[{label.upper()}]")
            st.progress(
                min(max(result["probe_confidence"], 0.0), 1.0),
                text=f"confidence {result['probe_confidence']:.3f}",
            )
            st.caption("Logistic regression fitted on our own train split.")

    if ground_truth is not None:
        st.write(f"Ground truth: `{ground_truth}`")

    st.caption(
        "Neither baseline outputs `insufficient_evidence` — a similarity score can't "
        "express 'not enough information'. That needs the O3 caption-grounded model."
    )


def render_encoder_sweep(results, threshold, ground_truth=None):
    rows = []
    for enc, r in results.items():
        rows.append(
            {
                "encoder": ENCODER_LABELS.get(enc, enc),
                "checkpoint": ENCODERS[enc],
                "score": None if r["score"] is None else round(r["score"], 4),
                "verdict": r["label"] or f"failed: {r['error'][:40]}",
            }
        )
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

    if ground_truth is not None:
        st.write(f"Ground truth: `{ground_truth}`")

    ok = {e: r for e, r in results.items() if r["score"] is not None}
    if len(ok) > 1:
        verdicts = {r["label"] for r in ok.values()}
        if len(verdicts) > 1:
            st.warning(
                "The encoders disagree on this pair. Disagreement concentrated on "
                "native-script claims is the Section 5.2 transfer effect this "
                "experiment is designed to measure."
            )
        else:
            st.info("All encoders agree on this pair.")
    st.caption(
        f"Same image and claim, same threshold ({threshold:.2f}); only the text-image "
        "encoder changes. Score differences are an encoder-transfer effect, not a data effect."
    )


st.title("🔎 IndicOOC")
st.write(
    "Out-of-context image–claim detection for Hindi / Bengali / Marathi / code-mixed posts."
)

try:
    get_model()
except Exception as e:
    st.error(f"Could not load SigLIP: {e}")
    st.stop()

threshold = st.sidebar.slider("Zero-shot threshold", 0.0, 1.0, DEFAULT_THRESHOLD, 0.01)
st.sidebar.caption("Default encoder: `google/siglip-base-patch16-224`")
if load_probe() is None:
    st.sidebar.warning("Probe not found — O2-ii column will be empty.")
else:
    st.sidebar.success("Trained probe loaded.")

tab_upload, tab_pilot, tab_encoders, tab_metrics = st.tabs(
    ["📤 Upload", "🗂️ Pilot example", "🌐 Encoder transfer", "📊 Results"]
)

with tab_upload:
    uploaded_file = st.file_uploader("Image", type=["png", "jpg", "jpeg", "webp"])
    claim_text = st.text_area("Claim text", placeholder="Paste the claim circulating with this image…")
    if st.button("Compare both baselines", type="primary", disabled=not (uploaded_file and claim_text)):
        image = Image.open(uploaded_file).convert("RGB")
        st.image(image, use_container_width=True)
        with st.spinner("Scoring…"):
            result = compare_both(image, claim_text, threshold)
        render_comparison(result, threshold)

with tab_pilot:
    pilot_df = read_csv(PILOT_CSV)
    if pilot_df is None:
        st.warning(f"Not found: {PILOT_CSV}")
    else:
        test_df = read_csv(TEST_CSV)
        test_ids = set(test_df["id"]) if test_df is not None else set()
        row_id = st.selectbox("Pilot row", pilot_df["id"].tolist())
        row = pilot_df[pilot_df["id"] == row_id].iloc[0]
        if row_id in test_ids:
            st.success("This row is in the held-out test split — the probe never saw it.")
        elif test_ids:
            st.info("This row was in training — the probe has seen it. Use a test-split row for a fair check.")
        st.write(f"**Claim ({row['language']}):** {row['claim_text']}")
        if st.button("Run this row", type="primary"):
            with st.spinner("Downloading image…"):
                image = load_image_from_url(row["image_url"])
            if image is None:
                st.error("Image failed to download (link rot).")
            else:
                st.image(image, use_container_width=True)
                with st.spinner("Scoring…"):
                    result = compare_both(image, row["claim_text"], threshold)
                render_comparison(result, threshold, ground_truth=row["label"])

with tab_encoders:
    st.markdown("**Does an English-trained encoder transfer to Indic script?**")
    st.write(
        "Section 5.2 of the synopsis flags this as an untested assumption. This tab scores "
        "one pair with every encoder so the assumption can be checked directly instead of assumed."
    )
    chosen = st.multiselect(
        "Encoders",
        list(ENCODERS),
        default=list(ENCODERS),
        format_func=lambda e: ENCODER_LABELS.get(e, e),
    )
    st.caption("First run downloads each checkpoint (~1.5 GB each) — allow a few minutes.")

    source = st.radio("Input", ["Pilot row", "Upload"], horizontal=True)

    if source == "Pilot row":
        pilot_df = read_csv(PILOT_CSV)
        if pilot_df is None:
            st.warning(f"Not found: {PILOT_CSV}")
        else:
            enc_row_id = st.selectbox("Row", pilot_df["id"].tolist(), key="enc_row")
            row = pilot_df[pilot_df["id"] == enc_row_id].iloc[0]
            st.write(f"**Claim ({row['language']}):** {row['claim_text']}")
            if st.button("Run encoder sweep", type="primary", disabled=not chosen):
                with st.spinner("Downloading image…"):
                    image = load_image_from_url(row["image_url"])
                if image is None:
                    st.error("Image failed to download (link rot).")
                else:
                    st.image(image, use_container_width=True)
                    with st.spinner("Scoring across encoders…"):
                        results = compare_encoders(image, row["claim_text"], threshold, chosen)
                    render_encoder_sweep(results, threshold, ground_truth=row["label"])
    else:
        enc_file = st.file_uploader("Image", type=["png", "jpg", "jpeg", "webp"], key="enc_upload")
        enc_claim = st.text_area("Claim text", key="enc_claim")
        if st.button("Run encoder sweep", type="primary", disabled=not (enc_file and enc_claim and chosen)):
            image = Image.open(enc_file).convert("RGB")
            st.image(image, use_container_width=True)
            with st.spinner("Scoring across encoders…"):
                results = compare_encoders(image, enc_claim, threshold, chosen)
            render_encoder_sweep(results, threshold)

with tab_metrics:
    metrics_df = read_csv(METRICS_CSV)
    if metrics_df is None:
        st.info("No metrics yet — run notebook 04 to generate outputs/baseline_comparison.csv.")
    else:
        st.markdown("**Baselines on the held-out test split**")
        st.dataframe(metrics_df, use_container_width=True, hide_index=True)

    enc_df = read_csv(ENCODER_CSV)
    if enc_df is not None:
        st.markdown("**Encoder transfer, by claim language**")
        st.dataframe(enc_df, use_container_width=True, hide_index=True)
    else:
        st.info("No encoder sweep yet — run notebook 05 to generate outputs/encoder_comparison.csv.")

    st.warning(
        "Pilot-scale numbers. With a handful of rows per split these figures show that "
        "the evaluation pipeline runs end to end — they are not yet a result worth "
        "reporting. Every baseline rerun unchanged once the dataset reaches target size."
    )
